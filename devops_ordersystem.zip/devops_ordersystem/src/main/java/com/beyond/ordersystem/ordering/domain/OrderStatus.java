package com.beyond.ordersystem.ordering.domain;

public enum OrderStatus {
    ORDERED, CANCELED
}
