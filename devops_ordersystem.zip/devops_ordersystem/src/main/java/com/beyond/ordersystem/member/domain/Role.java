package com.beyond.ordersystem.member.domain;

public enum Role {
    ADMIN, USER
}
