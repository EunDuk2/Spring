package com.beyond.ordersystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
